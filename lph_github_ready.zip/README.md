# Los Pollos Hermanos Coin — Static Site (GitHub Pages Ready)

This repository contains a static demo landing page for **Los Pollos Hermanos Coin (LPH)**.
It includes a hero banner, tokenomics, roadmap, team, and a placeholder **Buy** section.

## How to deploy on GitHub Pages (very quick)
1. Create a new GitHub repository (public).
2. Upload the contents of this ZIP into the repository root (index.html + assets/ + README.md).
3. Go to **Settings → Pages** and set the source to **main branch / root**.
4. After a minute GitHub Pages will provide a live URL:
   `https://<your-username>.github.io/<repo-name>/`

## Notes
- The **Buy** buttons currently link to `#` and the contract is `TBD`. Replace with your contract and DEX link when ready.
- This site is intentionally static and contains no backend — it's safe to host while you prepare your token launch.
